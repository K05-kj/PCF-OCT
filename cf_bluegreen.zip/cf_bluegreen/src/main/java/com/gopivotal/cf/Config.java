package com.gopivotal.cf;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Config {

}
